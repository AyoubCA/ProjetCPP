#pragma once
#ifndef CENTRE_H
#define CENTRE_H
#include<iostream>
#include"personne.h"
using namespace std;
class CentreFormation {
vector<Personne*> personnes;
public:
    // Destructeur pour lib�rer la m�moire
    ~Centre();

    // Ajouter une personne
    void ajouterPersonne(personne* Personne) {
        personnes.push_back(Personne);
    }

    // Afficher toutes les personnes
    void afficherPersonnes(){
        for (const auto& personne : personnes) {
            personne->afficher();
        }
    }

    // Compter le nombre de formateurs
    int compterFormateurs() const {
        int count = 0;
        for (const auto& personne : personnes) {
            if (dynamic_cast<Formateur*>(personne)) {
                count++;
            }
        }
        return count;
    }
};
#endif // CENTRE_H
