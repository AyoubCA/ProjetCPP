#pragma once
#ifndef PERSONNE_H
#define PERSONNE_H
#include <iostream>
#include <string>
#include <vector>
using namespace std;

class personne {
protected:
    string nom;
    int age;

public:
    // Constructeur
    personne(string="", int=1);

    // Constructeur de recopie
    personne(const personne&);

    // Destructeur
    virtual ~personne();
    //stters
    void setNom(string Nom){nom = Nom;}
    void setAge(int Age){age = Age;}
    // Getters
    string getNom(){ return nom; }
    int getAge(){ return age; }

    // Affichage
    virtual void afficher();
};
#endif
