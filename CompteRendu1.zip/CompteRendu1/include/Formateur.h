#pragma once
#ifndef FORMATEUR_H
#define FORMATEUR_H
#include"personne.h"
using namespace std;

class Formateur : public personne {
private:
    string specialite;

public:
    // Constructeur
    Formateur(string, int, string);

    // Constructeur de recopie
    Formateur(const Formateur& );

    // Destructeur
    ~Formateur();

    //setter
    void setSpecialite(string Specialite){specialite = Specialite;}

    // Getter
    string getSpecialite(){ return specialite; }

    // Affichage
    void afficher();
};

#endif
