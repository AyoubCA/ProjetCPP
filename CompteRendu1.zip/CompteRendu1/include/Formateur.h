#pragma once
#include <iostream>
#include <string>
using namespace std;

class Formateur {
protected:
    int cinn;
    string nom;
    string prenom;
    int nbl;
    string *lang;

public:
    Formateur(int,string,string, int);
    Formateur(const Formateur&);
    Formateur();
    void setNom(string Nom){nom = Nom;}
    void setPrenom(string Prenom){prenom = Prenom;}
    void setCin(int Cin){cinn = Cin;}
    string getNom(){ return nom; }
    string getPrenom(){ return prenom; }
    int getCin(){return cinn;}


    virtual ~Formateur();
    virtual void afficher();

};
