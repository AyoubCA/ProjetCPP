#include "personne.h"

personne::personne(string Nom, int Age) : nom(Nom), age(Age) {}
personne::personne(const personne& autre) : nom(autre.nom), age(autre.age) {}
void personne::afficher(){cout << "Nom: " << nom << ", Age: " << age << endl;}
personne::~personne(){}

