#include "Formateur.h"

Formateur::Formateur(string nom,int age,string specialite):personne(nom, age),specialite(specialite)
{
}
Formateur::Formateur(const Formateur& autre):personne(autre), specialite(autre.specialite) {}
Formateur::~Formateur(){}
void Formateur::afficher()
{
    cout<<"Formateur - Nom: "<<nom<<", Age: "<<age<<", Specialite: "<<specialite<<endl;
}
