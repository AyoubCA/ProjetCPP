#include "Centre.h"
#include <typeinfo>
using namespace std;
CentreFormation::CentreFormation() {
    char choix;
    int indice = 0;

    do {
        cout << "Voulez-vous ajouter un formateur ? (o/n) : ";
        cin >> choix;

        if (choix == 'o' || choix == 'O') {
            int typeFormateur;
            cout << "Tapez 1 pour ajouter un Formateur ou 2 pour un Formateur Specialise : ";
            cin >> typeFormateur;

            if (typeFormateur == 1) {
                int cinn, nbl;
                string nom, prenom;
                cout << "Entrez le CIN : ";
                cin >> cinn;
                cout << "Entrez le nom : ";
                cin >> nom;
                cout << "Entrez le prenom : ";
                cin >> prenom;
                cout << "Entrez le nombre de langues : ";
                cin >> nbl;
                Formateur* f = new Formateur(cinn, nom, prenom, nbl);
                ajouter(f, indice);
                indice++;
            } else if (typeFormateur == 2) {
                int cinn, nbl;
                string nom, prenom, specialite;
                cout << "Entrez le CIN : ";
                cin >> cinn;
                cout << "Entrez le nom : ";
                cin >> nom;
                cout << "Entrez le prenom : ";
                cin >> prenom;
                cout << "Entrez le nombre de langues : ";
                cin >> nbl;
                cout << "Entrez la specialite : ";
                cin >> specialite;
                FormateurSpec* fs = new FormateurSpec(Formateur(cinn, nom, prenom, nbl), specialite);
                ajouter(fs, indice);
                indice++;
            } else {
                cout << "Choix invalide, aucun formateur ajoute." << endl;
            }
        }
    } while (choix == 'o' || choix == 'O');
}
CentreFormation::CentreFormation(const CentreFormation &cf)
{
    Formateur* q;
    for(int i=0;i<cf.tab.size();i++)
    {
        if (typeid (*cf.tab[i]) == typeid (Formateur))
        {
            q=new Formateur(*cf.tab[i]);
        }
        else if (typeid (*cf.tab[i]) == typeid (Formateur))
        {
            q=new FormateurSpec(static_cast<const FormateurSpec&>(*cf.tab[i]));
        }
        tab.push_back(q);
    }
}
void CentreFormation::ajouter(Formateur* formateur, int indice) {
    if (indice >= 0 && indice <= tab.size()) {
        tab.insert(tab.begin() + indice, formateur);
    } else {
        cout << "Indice invalide, aucun formateur ajout�." << endl;
    }
}
void CentreFormation::afficher()
{
    for (int i = 0; i < tab.size(); i++) {
        tab[i]->afficher();
        cout << endl;
}
}
CentreFormation::~CentreFormation()
{
    for (int i=0;i<tab.size();i++) {
        delete tab[i];
    }
    tab.clear();
}
void CentreFormation::supprimer() {
    int indice;
    cout << "Entrez l'indice du formateur a supprimer : ";
    cin >> indice;
    if (indice >= 0 && indice < tab.size()) {
        delete tab[indice];
        tab.erase(tab.begin() + indice);
        cout << "Formateur a l'indice " << indice << " a ete supprime." << endl;
    } else {
        cout << "Indice invalide, suppression impossible." << endl;
    }
}

