#include "Centre.h"
Centre::~Centre()
{
    delete []personnes;
}
void Centre::ajouterPersonne(personne* Personne)
{
    personnes.push_back(Personne);
}

