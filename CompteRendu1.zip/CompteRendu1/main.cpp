#include <iostream>
#include"personne.h"
#include"Formateur.h"
using namespace std;

int main()
{
    personne p1("Ayoub", 21);
    Formateur f1("Nader", 21, "Infotronique");
    f1.setSpecialite("info");
    f1.afficher();
    return 0;
}
