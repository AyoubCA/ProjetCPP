#include <iostream>
#include"Formateur.h"
#include"FormateurSpec.h"
#include"Centre.h"
using namespace std;

int main()
{
    Formateur* f1 = new Formateur(155488, "Nader", "Gasmi", 2);
    Formateur* f2 = new Formateur(144444, "Ayoub", "Chaieb", 1);
    CentreFormation c1;
    c1.ajouter(f2,1);
    c1.ajouter(f1, 2);
    c1.afficher();
    c1.supprimer();
    c1.afficher();

    return 0;
}
